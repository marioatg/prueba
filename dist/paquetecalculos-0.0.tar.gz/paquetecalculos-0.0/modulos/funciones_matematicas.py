def sumar(op1,op2):
	print("el resultado de la suma es: ", op1+op2)

def restar(op1,op2):
	print("el resultado de la resta es:", op1-op2)

def multiplicar(op1,op2):
	print("el resultado de la multi es: ", op1*op2)
	