import funciones_matematicas

funciones_matematicas.restar(10,2)