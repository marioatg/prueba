from setuptools import setup 

setup(
	name="paquetecalculos",
	version="0.0",
	description="Paquete de matemáticas",
	author="Elma",
	author_email="mario.atg@ciencias.unam.mx",
	packages=["modulos"]


	)